# Invisible Failure / 看不见的失效

原创程序化知识动画：《为什么吸盘挂钩总在半夜掉下来？》

## 成片规格
1920×1080 / 60 fps / 2880 frames / 48 s / H.264 / AAC stereo.
动画：Remotion + React + TypeScript + SVG。所有运动由当前帧确定性计算。
无外部图片、视频或音乐素材。声音由 audio.py 使用固定种子合成，原创，无第三方采样。中文字幕，无配音。

## 复现
```bash
npm ci
python -m pip install numpy Pillow
python audio.py
npx tsc
npx remotion render src/index.tsx InvisibleFailure out/invisible-failure.mp4 --browser-executable=/usr/bin/chromium --codec=h264 --crf=18 --concurrency=2
python make_deliverables.py
```
Python 需要 numpy、Pillow；系统需要 FFmpeg、ffprobe、Chromium 与 Noto CJK 字体。
如果本机没有 /usr/bin/chromium，移除 browser-executable 参数，让 Remotion 安装其浏览器。

## 镜头时间表
01 00–03 浴室 / 慢推与橡胶弹响
02 03–06 产品特写 / 剥离、坠落冻结、穿入
03 06–09 剖面 / 弹性密封与低压空腔
04 09–13 空间压强场 / 压强差的法向作用
05 13–17 微观表面 / 沿密封边缘移动
06 17–21 漏气隧道 / 连续流线与纵深移动
07 21–25 时间 / 通道轮廓匹配时钟圆环
08 25–29 力学实验 / 压紧、摩擦、重量、剥离
09 29–33 回到浴室 / 微观泄漏与宏观坠落叠合
10 33–38 表面对比 / 横移揭示三种表面
11 38–43 安装演示 / 清洁、选面、安装
12 43–48 从边缘拉远 / 空间照明消失

## 系统
src/index.tsx 导出 SceneManager、CinematicCamera、TransitionEngine、SuctionCupModel、PressureVisualizer、MicroLeakPath、ContactSurface、TypographySystem、AudioTimeline。
TransitionEngine 使用锚定几何、相机缩放、平移、圆环匹配与空间收束；透明度混合作为桥接辅助。不是流体数值模拟或摄影级三维渲染，采用轻量 2.5D 矢量示意。

## 科学边界
普通无胶吸盘：安装时排出部分空气，弹性恢复与密封可产生内外压强差。没有假定完美真空。F≈ΔpA 表示法向压紧量级，不直接等同于垂直承重。向下负载依靠接触摩擦等作用抵抗，偏心负载也可能引起局部剥离。泄漏会逐步减小压强差；失效还可能受老化、污染、温度、变形与负载影响。
剧情时钟不是实验数据，不表示通用漏气速率。表面对比为定性示意，不提供未经验证的承重或使用时长。带胶复合式挂钩另按产品说明安装，建议不保证永不脱落。
