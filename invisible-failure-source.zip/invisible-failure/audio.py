import numpy as np,wave
sr=48000;n=sr*48;t=np.arange(n)/sr;rng=np.random.default_rng(41)
a=np.zeros(n)
# Original synthesized low room tone, tonal tension, rubber transients and filtered air.
a+=.014*np.sin(2*np.pi*48*t)+.007*np.sin(2*np.pi*72*t)
noise=rng.normal(0,1,n); low=np.convolve(noise,np.ones(41)/41,mode='same')
a+=low*.018
for start,dur,amp in [(2.82,.18,.3),(3.2,.45,.16),(5.7,.55,.08),(12.6,.7,.10),(16.6,.8,.1),(20.6,.65,.08),(28.8,.35,.25),(30.1,.7,.24),(37.8,.4,.08),(43,4.9,.045)]:
 i=int(start*sr);k=min(int(dur*sr),n-i);u=np.arange(k)/sr;env=np.sin(np.pi*np.arange(k)/k)**2
 a[i:i+k]+=amp*env*(low[i:i+k]*2+.22*np.sin(2*np.pi*(180*u+100*u*u)))
for st in [9,13,21,25,33,38]:
 i=int(st*sr);k=sr;u=np.arange(k)/sr;a[i:i+k]+=.035*np.exp(-u*5)*np.sin(2*np.pi*(220*u+30*u*u))
a*=np.minimum(t/1,1)*np.minimum((48-t)/1.3,1);a=np.clip(a,-.9,.9)
stereo=np.stack([a,np.roll(a,137)*.96],1)
with wave.open('public/soundtrack.wav','w') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((stereo*32767).astype('<i2').tobytes())
