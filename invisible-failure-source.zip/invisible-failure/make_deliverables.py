from PIL import Image,ImageDraw,ImageFont
import subprocess,json,os
os.makedirs('out/keyframes',exist_ok=True)
video='out/invisible-failure.mp4'
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
f=ImageFont.truetype(font,25);small=ImageFont.truetype(font,19);big=ImageFont.truetype(font,36)
shots=[(1.5,'01 深夜浴室'),(4.6,'02 坠落冻结'),(7.5,'03 吸盘剖面'),(11,'04 空间压强场'),(15,'05 微观密封边缘'),(19,'06 漏气隧道'),(23.2,'07 几个小时'),(27,'08 力学平衡'),(30.7,'09 瞬间与过程'),(35.5,'10 表面实验'),(40.7,'11 安装演示'),(44.3,'12 回归浴室')]
def extract(t,path):
 subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',video,'-frames:v','1',path],check=True)
def sheet():
 canvas=Image.new('RGB',(1920,1330),'#07121e');d=ImageDraw.Draw(canvas)
 d.text((32,22),'INVISIBLE FAILURE / 12 SHOTS',font=big,fill='#eeeadd')
 for i,(t,label) in enumerate(shots):
  path=f'out/keyframes/shot-{i+1:02}.png';extract(t,path)
  im=Image.open(path);im.thumbnail((620,349));x=20+(i%3)*640;y=90+(i//3)*310
  im=im.resize((526,296)) if False else im.resize((516,290))
  # 4 columns for cinematic aspect thumbnails
  x=20+(i%4)*480;y=90+(i//4)*400
  im=Image.open(path).resize((460,259));canvas.paste(im,(x,y))
  d.text((x,y+272),label,font=f,fill='#eeeadd');d.text((x,y+310),f'{t:04.1f} s',font=small,fill='#8bd4e6')
 canvas.save('out/storyboard.png')
trans=[(5.3,6.0,'01 穿入 / 冻结后的相机'),(8.3,9.0,'02 剖面 → 压强场'),(12.3,13.0,'03 压强场 → 密封边缘'),(16.3,17.0,'04 边缘 → 微观隧道'),(20.3,21.0,'05 隧道 → 时钟匹配'),(24.3,25.0,'06 时间 → 力学实验'),(28.3,29.0,'07 受力图收束 → 浴室'),(32.3,33.0,'08 横移揭示表面实验'),(37.3,38.0,'09 表面 → 产品演示'),(42.3,43.0,'10 产品 → 浴室'),(43.02,45.9,'11 微观边缘拉远'),(46.1,47.98,'12 空间照明渐隐')]
def transitions():
 canvas=Image.new('RGB',(1660,12*344+100),'#07121e');d=ImageDraw.Draw(canvas)
 d.text((24,20),'TRANSITIONS / START · MIDDLE · END',font=big,fill='#eeeadd')
 for row,(a,b,label) in enumerate(trans):
  y=92+row*344;d.text((24,y),label,font=f,fill='#e7a15a')
  for k,t in enumerate([a+.01,(a+b)/2,b+.015 if b<47 else b]):
   path=f'out/keyframes/transition-{row+1:02}-{k}.png';extract(t,path);im=Image.open(path).resize((528,297));canvas.paste(im,(24+k*548,y+38))
 canvas.save('out/transitions.png')
sheet();transitions()
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',video]))
open('out/verification.json','w').write(json.dumps(meta,ensure_ascii=False,indent=2))
v=next(x for x in meta['streams'] if x['codec_type']=='video')
assert (v['width'],v['height'],v['r_frame_rate'],v['nb_frames'],v['codec_name'])==(1920,1080,'60/1','2880','h264'),v
assert abs(float(meta['format']['duration'])-48)<.05
print('VERIFIED: H.264 / 1920x1080 / 60fps / 2880 frames / 48sec')
